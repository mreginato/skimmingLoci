filterLoci <-
function(aligns, thresholds, write.phylip=F, phylip.folder, write.nexus=F, nexus.folder, PIS=F, remove.empty.cells=F) {
  
  ###################################################
  getwd() -> wd
  
  labs <- c("Loci (total)", "Terminals (total)", "Terminals left",
            "Loci left", "Characters","Variable", "PIS", "Missing data (%)") 
  
  as.data.frame(matrix(ncol=8, nrow=nrow(thresholds))) -> n.stats
  colnames(n.stats) <- labs
  rownames(n.stats) <- paste("T1=",thresholds[,1],"_T2=",thresholds[,2],sep="")
  
  length(aligns) -> total.loci.n -> n.stats$`Loci (total)`
  length(unique(unlist(lapply(aligns, rownames)))) -> total.spp.n -> n.stats$`Terminals (total)`
  
  ###################################################
  
  for (j in 1:nrow(thresholds)) {
    setwd(wd)
    thresh1 = thresholds[j,1]
    thresh2 = thresholds[j,2]
    cat("\nGenerating t1 =", thresh1, "-", "t2 =", thresh2, fill=T)
    
    table(unlist(lapply(aligns, rownames))) -> spp.marker
    names(which(spp.marker < thresh1)) -> rem.spp
    names(which(spp.marker >= thresh1)) -> left.spp
    aligns.d <- lapply(aligns, FUN=function(x){which(is.na(match(rownames(x), rem.spp))) -> k0; if (length(k0) > 0) {x[k0,] -> x} else {x = NULL}})
    
    lapply(aligns.d, rownames) -> spp.marker
    unlist(lapply(spp.marker, length)) -> n.seqs
    
    if (thresh2 > 1) {
      keep <- which(n.seqs >= thresh2)
    } else {
      keep <- which(n.seqs >= (round(thresh2*length(left.spp), 0)))
    }
    aligns.d[keep] -> n.align
    if (remove.empty.cells) {
      lapply(n.align, trimAligns, min.missing = 1, edges.only=F, quiet = T) -> n.align
    } 
    
    length(n.align) -> n.stats$`Loci left`[j]
    fastConc(n.align, fill.with.gaps = T) -> n.align
    
    ### stats
    if (PIS) {
      nrow(n.align) -> n.stats$`Terminals left`[j]
      dstats(n.align) -> d0
      d0[1] -> n.stats$Characters[j]
      d0[2] -> n.stats$Variable[j]
      d0[3] -> n.stats$PIS[j]
      d0[4] -> n.stats$`Missing data (%)`[j]
    } else {
      nrow(n.align) -> n.stats$`Terminals left`[j]
      ncol(n.align) -> n.stats$Characters[j]
      freqs.n <- base.freq(n.align, all = T)
      round(freqs.n["-"] * 100,1) -> n.stats$`Missing data (%)`[j]
    }

    ### Phylip
    if (write.phylip) {
      cat("\nExporting...", fill=T)
      setwd(phylip.folder)
      my.write.phy(n.align, paste("Loci_Tspp_", thresh1, "_Tloci_", thresh2, ".phy", sep=""))
    }
    ### Nexus for SVDquartet
    if (write.nexus) {
      setwd(nexus.folder)
      
      ### Nuclear
      rownames(n.align) -> terms
      unlist(lapply(strsplit(terms, "_"), FUN=function(x)(x[1]))) -> spp
      data.frame(terms, spp) -> spp.key
      unique(spp) -> spp
      file0 <- paste("Nuclear_Tspp_", thresh1, "_Tloci_", thresh2, ".nex", sep="")
      write.nex(n.align, file0)
      cat("\nbegin sets;", file=file0, append=T)
      cat("\n\ttaxpartition species =", file=file0, append=T)
      for (i in 1:(length(spp)-1)) {
        range(which(spp.key$spp == spp[i])) -> r0
        cat("\n\t", spp[i], " : ", r0[1], "-", r0[2], ",", sep="", file=file0, append=T)
      }
      range(which(spp.key$spp == spp[length(spp)])) -> r0
      cat("\n\t", spp[length(spp)], " : ", r0[1], "-", r0[2], ";", sep="", file=file0, append=T)
      cat("\nend;", file=file0, fill=T, append=T)
    }
  rm(aligns.d); rm(n.align)
  }
  setwd(wd)
  return(n.stats)
}

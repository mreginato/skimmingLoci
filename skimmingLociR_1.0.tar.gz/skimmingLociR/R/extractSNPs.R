extractSNPs <-
function(dna) {
  dna -> a0
  tapply(a0, INDEX=col(a0), base.freq, freq=T, all=T) -> freq0
  lapply(freq0, "[", -c(5:17)) -> freq0
  lapply(freq0, FUN=function(x)(length(which(x > 0)))) -> v0
  which(v0 > 1) -> var0
  a0[,var0] -> a0
  return(a0)
}

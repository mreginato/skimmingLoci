writeRAxML <-
function (x, file = "align.phy", map=NULL, map.raxml=T, map.csv=T) 
{
  str2cha <- function(x) {
    unlist(strsplit(x, ""))
  }
  datatype <- "nc"
  ntax <- dim(x)[[1]]
  nchar <- dim(x)[[2]]
  taxnames <- rownames(x)
  xx <- vector(mode = "numeric")
  for (i in 1:ntax) xx <- c(xx, length(str2cha(taxnames[i])))
  diff <- max(xx) - xx
  for (i in 1:ntax) taxnames[i] <- paste(taxnames[i], paste(rep(" ", diff[i]), collapse = ""), sep = "")
  interleave <- nchar
  nbpart <- ceiling(nchar/interleave)
  pt <- matrix(nrow = nbpart, ncol = 2)
  pt[1, ] <- c(1, interleave)
  if (nbpart > 1) 
    for (i in 2:(dim(pt)[1])) {
      pt[i, ] <- c(pt[i - 1, 2] + 1, pt[i - 1, 2] + interleave)
      pt[nbpart, 2] <- nchar
    }
  phy <- paste(ntax, nchar)
  for (i in seq(along = pt[, 1])) {
    sm <- as.character(x[, pt[i, 1]:pt[i, 2]])
    if (is.null(dim(sm))) 
      sm <- as.matrix(sm, ncol = 1)
    sm <- apply(sm, 1, paste, collapse = "")
    if (i == 1) 
      sm <- paste(taxnames, sm)
    if (i < max(seq(along = pt[, 1]))) 
      sm <- c(sm, "")
    phy <- c(phy, sm)
  }
  cat(file=file)
  for (i in 1:length(phy)) {
    cat(phy[i], file=file, append = T, fill = T)
  }
  write(phy, file = file)
  if (is.null(map)==F) {
    sub(".phy", "", file) -> l0
    if (map.csv) {
      write.csv(map, paste(l0, "_map.csv", sep=""))
    }
    if (map.raxml) {
      as.data.frame(paste("DNA, p", 1:nrow(map), "=", map[,1], "-", map[,2], sep="")) -> r0
      write.table(r0, file=paste(l0, "_map.txt", sep=""), col.names = F, row.names = F, quote = F)
    }
  }
}

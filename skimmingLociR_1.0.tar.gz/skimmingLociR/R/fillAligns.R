fillAligns <-
function(dna, edges.only=T) {
  dna -> a0
  for (i in 1:nrow(a0)) {
    as.character(a0[i,]) -> r0
    r0 == "-" -> gaps
    fill.r <- fill.l <- vector()
    if (gaps[1]) {
      c(1:which(gaps == F)[1]) -> fill.l
    }
    if (gaps[length(gaps)]) {
      which(gaps == F) -> y
      c(y[length(y)]:length(gaps)) -> fill.r
    }
    c(fill.l, fill.r) -> fill
    if (length(fill) > 0) {
      r0[,fill] <- "n"
      as.DNAbin(r0) -> a0[i,]
    }
  }
  return(a0)
}

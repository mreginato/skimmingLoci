skimming.stats <-
function(concatenated = "Concatenated.phy", concatenated.map = "Concatenated_map.csv", conc.dir = NULL, reference = "References_full.fasta", ref.dir = NULL) {
  getwd() -> wd
  ### Split loci
  setwd(conc.dir)
  read.dna(concatenated) -> dna
  read.csv(concatenated.map, row.names=1) -> map
  setwd(wd)
  aligns <- vector("list", length=nrow(map)) 
  names(aligns) <- sub(".fas", "", rownames(map))
  for (i in 1:nrow(map)) {
    dna[,map[i,1]:map[i,2]] -> aligns[[i]]
  }
  
  ### Import reference
  setwd(ref.dir)
  read.dna(reference, "fasta") -> refs
  setwd(wd)
  for (i in 1:length(refs)) {
    refs[i] -> x
    trimAligns(as.matrix(x), min.missing = 1, edges.only=F, quiet = T) -> x
    as.list(x) -> refs[i]
  }
  unlist(lapply(refs, length)) -> refs.l
  
  ### Stats
  dstats <- data.frame()
  for (i in 1:length(aligns)) {
    aligns[[i]] -> a0
    l1 <- vector(length=nrow(a0))
    for (k in 1:nrow(a0)) {
      a0[k,] -> r0
      trimAligns(r0, min.missing = 1, edges.only=F, quiet = T) -> r0
      ncol(r0) -> l1[k]
    }
    refs.l[which(is.na(match(names(refs.l), names(aligns)[i])) == F)] -> l0
    cbind(l0,l1) -> l0
    l0[,2]/l0[,1] -> cov0
    cbind(l0,cov0) -> l0
    colnames(l0) <- c("ref", "target", "coverage")
    range(l0[,2]) -> range.0
    data.frame(reference_bp=l0[1,1], target_bp=paste(median(l0[,2]), " [", range.0[1], "-", range.0[2], "]", sep=""),
               coverage_median=round(median(l0[,3]),2), coverage_sd=round(sd(l0[,3]),2)) -> stats0
    alignStats(a0) -> s0
    s0[-c(1,6)] -> s0
    names(s0) <- c("aligned_bp", "variable_sites", "PIS", "missing_data", "sites_with_ambiguities")
    data.frame(stats0,t(data.frame(s0))) -> stats0
    rownames(stats0) <- names(aligns)[i]
    rbind(dstats,stats0) -> dstats
  }
  
  ### Stats spp.
  rownames(dna) -> spp
  lapply(aligns, rownames) -> aligns.spp
  spp.stats <- data.frame()
  for (i in 1:length(spp)) {
    spp[i] -> sp0
    lapply(aligns, FUN=function(x)(x[i,])) -> aligns.f
    lapply(aligns.f, trimAligns, min.missing = 1, edges.only = F, quiet=T) -> aligns.f
    which(unlist(lapply(aligns.f, nrow))==1) -> keep
    length(keep) -> total.loci
    aligns.f[keep] -> aligns.f
    refs.l[which(is.na(match(names(refs.l), names(aligns.f))) == F)] -> l0
    unlist(lapply(aligns.f, ncol)) -> l1
    cbind(l0,l1) -> l0
    l0[,2]/l0[,1] -> cov0
    cbind(l0,cov0) -> l0
    colnames(l0) <- c("ref", "target", "coverage")
    range(l0[,2]) -> range.0
    data.frame(loci_n=total.loci, target_bp=paste(median(l0[,2]), " [", range.0[1], "-", range.0[2], "]", sep=""),
               coverage_median=round(median(l0[,3]),2), coverage_sd=round(sd(l0[,3]),2)) -> stats0
    lapply(aligns.f, alignStats) -> s0
    as.numeric(unlist(lapply(s0, "[", 7))) -> s0
    s0/l0[,2] -> s0
    data.frame(stats0, ambiguities_median=round(median(s0),2), ambiguities_sd=round(sd(s0),2)) -> stats0
    rownames(stats0) <- sp0
    rbind(spp.stats,stats0) -> spp.stats
  }
  setwd(wd)
  return(list(loci.stats=dstats,spp.stats=spp.stats))
}

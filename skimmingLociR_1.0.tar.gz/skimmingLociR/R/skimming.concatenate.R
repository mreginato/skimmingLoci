skimming.concatenate <- function(fas.dir = NULL, conc.dir = NULL, file = "Concatenated.phy", trim.edges = T, trim.min = 4) {
  getwd() -> wd
  setwd(fas.dir)
  list.files(pattern="*.fas$") -> files
  sapply(files, read.dna, "fasta", simplify = F) -> aligns
  sub("\\.fas", "", names(aligns)) -> names(aligns)
  for (i in 1:length(aligns)) {
    aligns[[i]] -> a0
    trimAligns(a0, min.missing = 1, edges.only=F, quiet = T) -> a0
    if (trim.edges) {
      trimAligns(a0, min.missing = 1-(trim.min/nrow(a0)), quiet=T) -> a0
    }
    a0 -> aligns[[i]]
  }
  aligns[which(unlist(lapply(aligns, ncol)) > 0)] -> aligns 
  fastConc(aligns, fill.with.gaps = T, map = T) -> conc
  conc$map -> conc.map
  conc$align -> conc
  setwd(conc.dir)
  writeRAxML(conc, file="Concatenated.phy", map=conc.map)
  setwd(wd)
}

